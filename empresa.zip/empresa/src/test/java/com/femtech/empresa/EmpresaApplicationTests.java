//package com.femtech.empresa;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest(properties = "spring.profiles.active=test")
//class EmpresaApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
